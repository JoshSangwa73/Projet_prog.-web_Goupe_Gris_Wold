let h2 = document.querySelectorAll("h2");
let table = document.querySelectorAll("table");
let a = document.querySelectorAll("a");

h2[0].onclick = function ()
{
    if(table[0].style.display == "none")
    {
        table[0].style.display = "inline-table";
    a[0].style.display = "inline-table";
    }

    else
    {
        table[0].style.display ="none";
        a[0].style.display ="none";
    }
}
h2[1].onclick = function ()
{
    if(table[1].style.display == "none")
    {
        table[1].style.display = "inline-table";
    a[1].style.display = "inline-table";
    }

    else
    {
        table[1].style.display ="none";
        a[1].style.display ="none";
    }
}
h2[2].onclick = function ()
{
    if(table[2].style.display == "none")
    {
        table[2].style.display = "inline-table";
    a[2].style.display = "inline-table";
    }

    else
    {
        table[2].style.display ="none";
        a[2].style.display ="none";
    }
}
h2[3].onclick = function ()
{
    if(table[3].style.display == "none")
    {
        table[3].style.display = "inline-table";
    a[3].style.display = "inline-table";
    }

    else
    {
        table[3].style.display ="none";
        a[3].style.display ="none";
    }
}
h2[4].onclick = function ()
{
    if(table[4].style.display == "none")
    {
        table[4].style.display = "inline-table";
    a[4].style.display = "inline-table";
    }

    else
    {
        table[4].style.display ="none";
        a[4].style.display ="none";
    }
}
h2[5].onclick = function ()
{
    if(table[5].style.display == "none")
    {
        table[5].style.display = "inline-table";
    a[5].style.display = "inline-table";
    }

    else
    {
        table[5].style.display ="none";
        a[5].style.display ="none";
    }
}
